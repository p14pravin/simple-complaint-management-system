Compliant Managment System

path for admin Dashboard : localhost/sad/admin/
path for user : localhost/sad/

admin login Credentials-

Email address:  admin@cms.com
Password: 		pass@123


user login Credentials-

Email:		 p14pravin@gmail.com
Password: 	 pass@123


Functions of CMS for User:
1] Add Compliant
2] View Compliant
3] Update Compliant
4] Delete Compliant
5] Register
6] Login

Functions of CMS For Admin:
1] Update Complaint Status
2] Remark Complaint


Update and Delete function of Complaint will get Disabled when compliant goes in process.